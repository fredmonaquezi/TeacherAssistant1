import SwiftUI
import Combine

final class MacNavigationState: ObservableObject {
    @Published private(set) var depth: Int = 0

    func reset() {
        if depth != 0 {
            depth = 0
        }
    }

    func push() {
        depth += 1
    }

    func pop() {
        depth = max(0, depth - 1)
    }
}

#if os(macOS)
private struct MacNavigationRootModifier: ViewModifier {
    @EnvironmentObject private var macNavigationState: MacNavigationState

    func body(content: Content) -> some View {
        content
            .navigationTitle("")
            .navigationBarBackButtonHidden(true)
            .onAppear {
                macNavigationState.reset()
            }
    }
}

private struct MacNavigationDepthModifier: ViewModifier {
    @EnvironmentObject private var macNavigationState: MacNavigationState
    @State private var isCounted = false

    func body(content: Content) -> some View {
        content
            .navigationTitle("")
            .navigationBarBackButtonHidden(true)
            .onAppear {
                guard !isCounted else { return }
                isCounted = true
                macNavigationState.push()
            }
            .onDisappear {
                guard isCounted else { return }
                isCounted = false
                macNavigationState.pop()
            }
    }
}
#else
private struct MacNavigationRootModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
    }
}

private struct MacNavigationDepthModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
    }
}
#endif

extension View {
    func macNavigationRoot() -> some View {
        modifier(MacNavigationRootModifier())
    }

    func macNavigationDepth() -> some View {
        modifier(MacNavigationDepthModifier())
    }
}
