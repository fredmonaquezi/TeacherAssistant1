//
//  AssessmentsView.swift
//  TeacherAssistant
//
//  Created by Frederico Monaquezi Fernandes on 19/01/26.
//

import SwiftUI

struct AssessmentsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AssessmentsView()
}
