//
//  AssessmentCategory.swift
//  TeacherAssistant
//
//  Created by Frederico Monaquezi Fernandes on 19/01/26.
//

import Foundation
